const { response, request } = require('express')
const express = require('express')
const { MongoClient } = require('mongodb')
const cors = require('cors')
const app = express()
app.use(cors())
app.use(express.json())


//const url = "mongodb+srv://yaswanth648:admin@cluster0.mmjbpiy.mongodb.net/?retryWrites=true&w=majority";
const url="mongodb://0.0.0.0:27017/?retryWrites=true&w=majority";
//const url="mongodb://localhost:27017/?authMechanism=DEFAULT";
const client = new MongoClient(url);
client.connect()
const db = client.db("Users");
const col = db.collection("details");
const items=db.collection("items");
const cart=db.collection("carts");
const near=db.collection("nearby");
const order=db.collection("orders");
const seats=db.collection("seats");
var data=null;
var mail=null;
var restaurent=null;

app.post('/', (request, response) => {
    console.log(request.body)
    col.insertOne(request.body)
    response.send("success")
})

app.post('/logout',(request,response)=>{
    mail=null;
    data=null;
    restaurent=null;
})

app.post('/placeorder',(request,response)=>{
    /*async function uploading()
    {
        try{
            order.insertOne(request.body);
            console.log(request.body);
            response.send("ok");
        }
        finally{

        }
    }uploading.catch(console.dir)*/
    order.insertOne(request.body);
    response.send("success");
})



app.get('/allord',(request,response)=>{
    async function  finder()
    {
        try{
            const uorder=await order.find({email:mail}).toArray();
            response.send(uorder);
        }
        finally{

        }
    }finder().catch(console.dir)
})

app.get('/allorders',(request,response)=>{
    async function  finder()
    {
        try{
            const uorder=await order.find().toArray();
            response.send(uorder);
        }
        finally{

        }
    }finder().catch(console.dir)
})
app.post('/newpass',(request,response)=>{
    async function update() {
        try {
            const res = await col.findOne({
                email: mail
            }
            )
            if(res.password==request.body.old)
            {
                const result = await col.updateOne({email:mail},{$set:{password:request.body.new}},{upsert:true})
            response.send("Updated Successfully");
            }
            else
            {
                response.send("Incorrect Old Password");
            }
            
        }
        finally {

        }

    }
    update().catch(console.dir)

})

app.get('/users',(request,response)=>{
    async function findall()
    {
        try{
            const alldet= await col.find().toArray();
            response.send(alldet);
        }
        finally{

        }
    }findall().catch(console.dir)
})

app.get('/items',(request,response)=>{
    async function item()
    {
        try{
            console.log(request.query.itype);
            const foods =await items.find({type:request.query.itype}).toArray();
            response.send(foods);
            //console.log(foods);
        }
        finally {

        }
    }item().catch(console.dir)
})
app.get('/check', (request, response) => {
    console.log(request.query)

    async function find() {
        try {
            const result = await col.findOne({
                email: request.query.email
            }
            )
            console.log(result)
            mail=result.email;
            console.log(mail);
            if (result === null) {
                response.send("fail")
            }
            else {
                if (result.password === request.query.password) {
                    response.send("pass")
                }
                else {
                    response.send("fail")
                }
            }
        }
        finally {

        }

    }
    find().catch(console.dir)

})
app.post('/proupdate',(request,response)=>{
    async function update() {
        try {
            const result = await col.updateOne({email:mail},{$set:{address:request.body.address,fname:request.body.fname,lname:request.body.lname,mobile:request.body.mobile,age:request.body.age,gender:request.body.gender}},{upsert:true})
            response.send(null);
        }
        finally {

        }

    }
    update().catch(console.dir)

})

app.post('/img',(request,response)=>{
    async function img() {
        try {
            col.updateOne({email:mail},{$set:{image:request.query.image}});
            console.log("image uploaded");
        }
        finally{}
    }img().catch(console.dir);
})
app.get('/prof',(request,response)=>{
    async function finder() {
        try {
            const result = await col.findOne({
                email: mail
            }
            )
            data=result
        }
        finally {

        }
    }
    response.send(data);
    finder().catch(console.dir)
})

app.post('/updateaddr', (request, response) => {
    console.log(request.body.addr)

    async function update() {
        try {
            const result = await col.updateOne({email:request.body.email},{$set:{address:request.body.addr}},{upsert:true})
            response.send(null);
        }
        finally {

        }

    }
    update().catch(console.dir)

})

app.get('/mail',(request,response)=>{
    response.send(mail);
})



app.post('/cartpost',(request,response)=>{
    //var carty={'itemName':request.query.itemName,'itemImage':request.query.itemImage,'itemPrice':request.query.itemPrice,'email':mail}
    cart.insertOne(request.body);
    response.send("done");
})

app.get('/cartget',(request,response)=>{
    async function get()
    {
        try{
            const carty = await cart.find({email:mail}).toArray();
            response.send(carty);
        }
        finally{

        }
    }get().catch(console.dir)
})

app.post('/remcart',(request,response)=>{
    var ans=cart.deleteOne({email:mail,itemName:request.body.iname});
    response.send("Done");
   /* 
    cart.remove({email:mail,itemName:"Dosa"});
    console.log("deleted");
    */
})

app.post('/remorder',(request,response)=>{
    console.log(request.body.id);
    var ans=order.deleteOne({email:mail,iname:request.body.iname,price:request.body.price,status:request.body.status});
})

app.post('/restaurent',(request,response)=>{
    restaurent=request.body.restaurent;
})
app.post('/seats',(request,response)=>{
    var det={email:mail,restaurent:restaurent,seats:request.body.seats};
    seats.insertOne(det);
})

app.post('/unlinkseats',(request,response)=>{
    console.log(request.body.id);
    var ans=seats.deleteOne({email:request.body.mail,seats:request.body.seats});
    response.send("Deleted"+ans);
})


app.get('/nearby',(request,response)=>{
    async function nearby()
    {
        try{
            console.log(request.query.city);
            var rest=await near.find({place:request.query.city}).toArray();
            //var rest=await near.find({place:"Vijayawada"}).toArray();
            response.send(rest);
        }
        finally{
            
        }
    }nearby().catch(console.dir)
})
app.get('/getseats',(request,response)=>{
    async function nearby()
    {
        try{
           var rest=await seats.find({email:mail}).toArray();
           console.log(rest);
            response.send(rest);
        }
        finally{
            
        }
    }nearby().catch(console.dir)
})
app.get('/getallseats',(request,response)=>{
    async function nearby()
    {
        try{
           var rest=await seats.find().toArray();
           console.log(rest);
            response.send(rest);
        }
        finally{
            
        }
    }nearby().catch(console.dir)
})

app.listen(8081);
console.log('server started');